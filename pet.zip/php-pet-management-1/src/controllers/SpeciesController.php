<?php
class SpeciesController {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function create($name) {
        $stmt = $this->db->prepare("INSERT INTO species (name) VALUES (:name)");
        $stmt->bindParam(':name', $name);
        return $stmt->execute();
    }

    public function read($id) {
        $stmt = $this->db->prepare("SELECT * FROM species WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function update($id, $name) {
        $stmt = $this->db->prepare("UPDATE species SET name = :name WHERE id = :id");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM species WHERE id = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function list() {
        $stmt = $this->db->query("SELECT * FROM species");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>