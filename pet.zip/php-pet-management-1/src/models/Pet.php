<?php
class Pet {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function create($name, $species_id, $age, $description) {
        $stmt = $this->db->prepare("INSERT INTO pets (name, species_id, age, description) VALUES (:name, :species_id, :age, :description)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':species_id', $species_id);
        $stmt->bindParam(':age', $age);
        $stmt->bindParam(':description', $description);
        return $stmt->execute();
    }

    public function read($id) {
        $stmt = $this->db->prepare("SELECT * FROM pets WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function update($id, $name, $species_id, $age, $description) {
        $stmt = $this->db->prepare("UPDATE pets SET name = :name, species_id = :species_id, age = :age, description = :description WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':species_id', $species_id);
        $stmt->bindParam(':age', $age);
        $stmt->bindParam(':description', $description);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM pets WHERE id = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function list() {
        $stmt = $this->db->query("SELECT * FROM pets");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>