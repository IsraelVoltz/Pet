<?php
// filepath: c:\xampp\htdocs\php-pet-management\src\views\pets\form.php

require_once '../../config/database.php';
require_once '../../src/models/Pet.php';

$pet = new Pet($database);
$action = isset($_GET['id']) ? 'edit' : 'create';
$petData = null;

if ($action === 'edit') {
    $petData = $pet->getPetById($_GET['id']);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($action); ?> Pet</title>
</head>
<body>
    <h1><?php echo ucfirst($action); ?> Pet</h1>
    <form action="<?php echo $action === 'edit' ? 'edit.php?id=' . $_GET['id'] : 'create.php'; ?>" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $petData ? htmlspecialchars($petData['name']) : ''; ?>" required>
        
        <label for="species">Species:</label>
        <input type="text" id="species" name="species" value="<?php echo $petData ? htmlspecialchars($petData['species']) : ''; ?>" required>
        
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="<?php echo $petData ? htmlspecialchars($petData['age']) : ''; ?>" required>
        
        <input type="submit" value="<?php echo ucfirst($action); ?> Pet">
    </form>
    <a href="list.php">Back to Pet List</a>
</body>
</html>