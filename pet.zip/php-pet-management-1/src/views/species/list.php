<?php
require_once '../../src/controllers/SpeciesController.php';

$speciesController = new SpeciesController($database);
$speciesList = $speciesController->getAllSpecies();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Species List</title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <?php include '../layout.php'; ?>
    
    <div class="container">
        <h1>Species List</h1>
        <a href="create.php" class="btn">Add New Species</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($speciesList as $species): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($species['id']); ?></td>
                        <td><?php echo htmlspecialchars($species['name']); ?></td>
                        <td><?php echo htmlspecialchars($species['description']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo htmlspecialchars($species['id']); ?>">Edit</a>
                            <a href="delete.php?id=<?php echo htmlspecialchars($species['id']); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>