<?php
// filepath: c:\xampp\htdocs\php-pet-management\src\views\species\form.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($species) ? 'Edit Species' : 'Create Species'; ?></title>
</head>
<body>
    <h1><?php echo isset($species) ? 'Edit Species' : 'Create Species'; ?></h1>
    <form action="<?php echo isset($species) ? '/public/species/edit.php?id=' . $species['id'] : '/public/species/create.php'; ?>" method="POST">
        <label for="name">Species Name:</label>
        <input type="text" id="name" name="name" value="<?php echo isset($species) ? htmlspecialchars($species['name']) : ''; ?>" required>
        
        <input type="submit" value="<?php echo isset($species) ? 'Update Species' : 'Create Species'; ?>">
    </form>
    <a href="/public/species/list.php">Back to Species List</a>
</body>
</html>