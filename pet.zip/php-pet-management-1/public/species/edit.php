<?php
session_start();
require_once '../../config/database.php';
require_once '../../src/controllers/SpeciesController.php';

$database = new Database();
$db = $database->getConnection();
$speciesController = new SpeciesController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];

    if ($speciesController->updateSpecies($id, $name, $description)) {
        header("Location: list.php");
        exit();
    } else {
        $error = "Failed to update species.";
    }
} else {
    $id = $_GET['id'];
    $species = $speciesController->getSpeciesById($id);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Species</title>
</head>
<body>
    <h1>Edit Species</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form action="edit.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $species['id']; ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $species['name']; ?>" required>
        <br>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo $species['description']; ?></textarea>
        <br>
        <button type="submit">Update Species</button>
    </form>
    <a href="list.php">Back to Species List</a>
</body>
</html>