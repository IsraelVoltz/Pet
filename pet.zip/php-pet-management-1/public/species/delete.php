<?php
require_once '../../config/database.php';
require_once '../../src/controllers/SpeciesController.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$speciesController = new SpeciesController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];
    if ($speciesController->delete($id)) {
        header("Location: /species/list.php?message=Species deleted successfully");
        exit();
    } else {
        $error = "Failed to delete species.";
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $species = $speciesController->getById($id);
    if (!$species) {
        header("Location: /species/list.php?error=Species not found");
        exit();
    }
} else {
    header("Location: /species/list.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Species</title>
</head>
<body>
    <h1>Delete Species</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <p>Are you sure you want to delete the species: <strong><?php echo htmlspecialchars($species['name']); ?></strong>?</p>
    <form method="POST" action="delete.php">
        <input type="hidden" name="id" value="<?php echo $species['id']; ?>">
        <button type="submit">Yes, delete</button>
        <a href="/species/list.php">Cancel</a>
    </form>
</body>
</html>