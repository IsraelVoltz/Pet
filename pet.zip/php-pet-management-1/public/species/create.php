<?php
require_once '../../config/database.php';
require_once '../../src/controllers/SpeciesController.php';

$database = new Database();
$db = $database->getConnection();
$speciesController = new SpeciesController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';

    if (!empty($name)) {
        $speciesController->createSpecies($name);
        header("Location: /species/list.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Species</title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <div class="container">
        <h2>Create New Species</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label for="name">Species Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <button type="submit">Create Species</button>
        </form>
        <a href="/species/list.php">Back to Species List</a>
    </div>
</body>
</html>