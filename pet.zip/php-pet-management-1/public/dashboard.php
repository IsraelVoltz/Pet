<?php
session_start();
require_once '../config/database.php';
require_once '../src/controllers/AuthController.php';

$database = new Database();
$db = $database->getConnection();
$authController = new AuthController($db);

if (!$authController->isAuthenticated()) {
    header("Location: /login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Welcome to the Pet Management Dashboard</h1>
        <p class="lead">Manage your pets and species from here.</p>
        <a href="/public/pets/list.php" class="btn btn-primary">Manage Pets</a>
        <a href="/public/species/list.php" class="btn btn-secondary">Manage Species</a>
        <a href="/logout.php" class="btn btn-danger">Logout</a>
    </div>
</body>
</html>