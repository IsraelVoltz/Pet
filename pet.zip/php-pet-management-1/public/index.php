<?php
require_once '../config/database.php';
require_once '../src/controllers/AuthController.php';
require_once '../src/controllers/PetController.php';
require_once '../src/controllers/SpeciesController.php';

session_start();

$database = new Database();
$db = $database->getConnection();

$authController = new AuthController($db);
$petController = new PetController($db);
$speciesController = new SpeciesController($db);

$requestUri = $_SERVER['REQUEST_URI'];

if (strpos($requestUri, '/login.php') !== false) {
    require '../src/views/auth/login_form.php';
} elseif (strpos($requestUri, '/logout.php') !== false) {
    $authController->logout();
} elseif ($authController->isAuthenticated()) {
    if (strpos($requestUri, '/dashboard.php') !== false) {
        require '../src/views/layout.php';
        // Include dashboard content here
    } elseif (strpos($requestUri, '/pets/') !== false) {
        // Handle pet-related requests
        if (strpos($requestUri, '/pets/list.php') !== false) {
            $pets = $petController->listPets();
            require '../src/views/pets/list.php';
        } elseif (strpos($requestUri, '/pets/create.php') !== false) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $petController->createPet($_POST);
                header("Location: /pets/list.php");
                exit();
            }
            require '../src/views/pets/form.php';
        } elseif (strpos($requestUri, '/pets/edit.php') !== false) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $petController->updatePet($_POST);
                header("Location: /pets/list.php");
                exit();
            }
            $pet = $petController->getPet($_GET['id']);
            require '../src/views/pets/form.php';
        } elseif (strpos($requestUri, '/pets/delete.php') !== false) {
            $petController->deletePet($_GET['id']);
            header("Location: /pets/list.php");
            exit();
        }
    } elseif (strpos($requestUri, '/species/') !== false) {
        // Handle species-related requests
        if (strpos($requestUri, '/species/list.php') !== false) {
            $species = $speciesController->listSpecies();
            require '../src/views/species/list.php';
        } elseif (strpos($requestUri, '/species/create.php') !== false) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $speciesController->createSpecies($_POST);
                header("Location: /species/list.php");
                exit();
            }
            require '../src/views/species/form.php';
        } elseif (strpos($requestUri, '/species/edit.php') !== false) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $speciesController->updateSpecies($_POST);
                header("Location: /species/list.php");
                exit();
            }
            $species = $speciesController->getSpecies($_GET['id']);
            require '../src/views/species/form.php';
        } elseif (strpos($requestUri, '/species/delete.php') !== false) {
            $speciesController->deleteSpecies($_GET['id']);
            header("Location: /species/list.php");
            exit();
        }
    }
} else {
    require '../src/views/auth/login_form.php';
}
?>