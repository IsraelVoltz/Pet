<?php
require_once '../src/controllers/AuthController.php';
require_once '../config/database.php';

$authController = new AuthController($database);
$authController->logout();
?>