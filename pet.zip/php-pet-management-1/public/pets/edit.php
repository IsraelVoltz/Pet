<?php
require_once '../../config/database.php';
require_once '../../src/controllers/PetController.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit();
}

$petController = new PetController($database);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petId = $_POST['id'];
    $name = $_POST['name'];
    $species = $_POST['species'];
    $age = $_POST['age'];

    $petController->updatePet($petId, $name, $species, $age);
    header("Location: /pets/list.php");
    exit();
}

$petId = $_GET['id'];
$pet = $petController->getPetById($petId);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pet</title>
</head>
<body>
    <h1>Edit Pet</h1>
    <form action="edit.php" method="POST">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($pet['id']); ?>">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($pet['name']); ?>" required>
        <br>
        <label for="species">Species:</label>
        <input type="text" name="species" id="species" value="<?php echo htmlspecialchars($pet['species']); ?>" required>
        <br>
        <label for="age">Age:</label>
        <input type="number" name="age" id="age" value="<?php echo htmlspecialchars($pet['age']); ?>" required>
        <br>
        <button type="submit">Update Pet</button>
    </form>
    <a href="/pets/list.php">Cancel</a>
</body>
</html>