<?php
require_once '../../config/database.php';
require_once '../../src/controllers/PetController.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$petController = new PetController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $species_id = $_POST['species_id'];
    $age = $_POST['age'];
    $description = $_POST['description'];

    if ($petController->createPet($name, $species_id, $age, $description)) {
        header("Location: /pets/list.php");
        exit();
    } else {
        $error = "Failed to create pet.";
    }
}

$speciesList = $petController->getSpeciesList();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Pet</title>
</head>
<body>
    <h1>Create New Pet</h1>
    <?php if (isset($error)): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form action="create.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="species_id">Species:</label>
        <select id="species_id" name="species_id" required>
            <?php foreach ($speciesList as $species): ?>
                <option value="<?php echo $species['id']; ?>"><?php echo $species['name']; ?></option>
            <?php endforeach; ?>
        </select>
        
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" required>
        
        <label for="description">Description:</label>
        <textarea id="description" name="description"></textarea>
        
        <button type="submit">Create Pet</button>
    </form>
    <a href="/pets/list.php">Back to Pet List</a>
</body>
</html>