<?php
require_once '../../config/database.php';
require_once '../../src/controllers/PetController.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$petController = new PetController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petId = $_POST['pet_id'];
    if ($petController->deletePet($petId)) {
        header("Location: /pets/list.php?message=Pet deleted successfully");
    } else {
        header("Location: /pets/list.php?error=Failed to delete pet");
    }
    exit();
} else {
    header("Location: /pets/list.php");
    exit();
}
?>