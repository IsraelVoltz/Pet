<?php
require_once '../../config/database.php';
require_once '../../src/controllers/PetController.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$petController = new PetController($db);
$pets = $petController->getAllPets();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet List</title>
    <link rel="stylesheet" href="/public/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Pet List</h1>
        <a href="create.php" class="btn">Add New Pet</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Species</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pets as $pet): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pet['id']); ?></td>
                        <td><?php echo htmlspecialchars($pet['name']); ?></td>
                        <td><?php echo htmlspecialchars($pet['species']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo htmlspecialchars($pet['id']); ?>">Edit</a>
                            <a href="delete.php?id=<?php echo htmlspecialchars($pet['id']); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>