# PHP Pet Management System

## Overview
The PHP Pet Management System is a web application that allows users to manage pets and species. It includes user authentication, CRUD operations for pets and species, and a coherent visual interface.

## Features
- User authentication (login/logout)
- CRUD operations for pets
- CRUD operations for species
- User-friendly interface

## Project Structure
```
php-pet-management
├── public
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   ├── dashboard.php
│   ├── pets
│   │   ├── create.php
│   │   ├── edit.php
│   │   ├── delete.php
│   │   └── list.php
│   └── species
│       ├── create.php
│       ├── edit.php
│       ├── delete.php
│       └── list.php
├── src
│   ├── controllers
│   │   ├── AuthController.php
│   │   ├── PetController.php
│   │   └── SpeciesController.php
│   ├── models
│   │   ├── User.php
│   │   ├── Pet.php
│   │   └── Species.php
│   └── views
│       ├── layout.php
│       ├── auth
│       │   └── login_form.php
│       ├── pets
│       │   ├── form.php
│       │   └── list.php
│       └── species
│           ├── form.php
│           └── list.php
├── config
│   └── database.php
├── sql
│   └── schema.sql
└── README.md
```

## Installation
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Set up the database using the SQL schema provided in `sql/schema.sql`.
4. Configure the database connection settings in `config/database.php`.
5. Start a local server (e.g., XAMPP) and navigate to `http://localhost/php-pet-management/public`.

## Usage
- Access the login page at `http://localhost/php-pet-management/public/login.php`.
- After logging in, you will be redirected to the dashboard.
- Use the navigation to manage pets and species.

## Contributing
Feel free to fork the repository and submit pull requests for any improvements or bug fixes.