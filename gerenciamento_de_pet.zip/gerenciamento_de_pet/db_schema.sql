-- Database schema for pet management system

CREATE DATABASE IF NOT EXISTS gerenciamento_de_pet;
USE gerenciamento_de_pet;

-- Users table for authentication
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL -- store hashed passwords
);

-- Species table
CREATE TABLE especies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    especie VARCHAR(100) NOT NULL UNIQUE
);

-- Pets table
CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    nascimento DATE NOT NULL,
    especie_id INT NOT NULL,
    prontuario TEXT,
    genero ENUM('macho', 'femea') NOT NULL,
    FOREIGN KEY (especie_id) REFERENCES especies(id) ON DELETE RESTRICT ON UPDATE CASCADE
);
