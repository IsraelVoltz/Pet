<?php
session_start();
require_once 'includes/db.php';
include 'includes/header.php';
?>

<h1>Bem-vindo ao Sistema de Gerenciamento de Pet</h1>
<p>Escolha uma opção no menu acima.</p>

<?php
include 'includes/footer.php';
?>
