<?php
session_start();
require_once 'includes/db.php';
include 'includes/header.php';

// Handle create
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $especie = $_POST['especie'];
    $stmt = $pdo->prepare("INSERT INTO especies (especie) VALUES (?)");
    $stmt->execute([$especie]);
    header('Location: especies.php');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM especies WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: especies.php');
    exit;
}

// Handle edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit'])) {
    $id = $_POST['id'];
    $especie = $_POST['especie'];
    $stmt = $pdo->prepare("UPDATE especies SET especie = ? WHERE id = ?");
    $stmt->execute([$especie, $id]);
    header('Location: especies.php');
    exit;
}

// Fetch all especies
$stmt = $pdo->query("SELECT * FROM especies");
$especies = $stmt->fetchAll();
?>

<h2>Gerenciamento de Espécies</h2>

<!-- Create Form -->
<h3>Adicionar Espécie</h3>
<form method="post">
    <div class="mb-3">
        <label for="especie" class="form-label">Espécie</label>
        <input type="text" class="form-control" id="especie" name="especie" required>
    </div>
    <button type="submit" name="create" class="btn btn-primary">Adicionar</button>
</form>

<!-- List -->
<h3 class="mt-4">Lista de Espécies</h3>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Espécie</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($especies as $esp): ?>
        <tr>
            <td><?php echo $esp['id']; ?></td>
            <td><?php echo htmlspecialchars($esp['especie']); ?></td>
            <td>
                <button class="btn btn-sm btn-warning" onclick="editEspecie(<?php echo $esp['id']; ?>, '<?php echo htmlspecialchars($esp['especie']); ?>')">Editar</button>
                <a href="?delete=<?php echo $esp['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Edit Form (hidden initially) -->
<div id="editForm" style="display:none;">
    <h3>Editar Espécie</h3>
    <form method="post">
        <input type="hidden" id="editId" name="id">
        <div class="mb-3">
            <label for="editEspecie" class="form-label">Espécie</label>
            <input type="text" class="form-control" id="editEspecie" name="especie" required>
        </div>
        <button type="submit" name="edit" class="btn btn-primary">Salvar</button>
        <button type="button" class="btn btn-secondary" onclick="cancelEdit()">Cancelar</button>
    </form>
</div>

<script>
function editEspecie(id, especie) {
    document.getElementById('editId').value = id;
    document.getElementById('editEspecie').value = especie;
    document.getElementById('editForm').style.display = 'block';
}
function cancelEdit() {
    document.getElementById('editForm').style.display = 'none';
}
</script>

<?php
include 'includes/footer.php';
?>
