<?php
session_start();
require_once 'includes/db.php';
include 'includes/header.php';

// Fetch especies for select
$stmt = $pdo->query("SELECT * FROM especies");
$especies = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle create
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $nome = $_POST['nome'];
    $nascimento = $_POST['nascimento'];
    $especie_id = $_POST['especie_id'];
    $prontuario = $_POST['prontuario'];
    $genero = $_POST['genero'];
    $stmt = $pdo->prepare("INSERT INTO pets (nome, nascimento, especie_id, prontuario, genero) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nome, $nascimento, $especie_id, $prontuario, $genero]);
    header('Location: pets.php');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM pets WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: pets.php');
    exit;
}

// Handle edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $nascimento = $_POST['nascimento'];
    $especie_id = $_POST['especie_id'];
    $prontuario = $_POST['prontuario'];
    $genero = $_POST['genero'];
    $stmt = $pdo->prepare("UPDATE pets SET nome = ?, nascimento = ?, especie_id = ?, prontuario = ?, genero = ? WHERE id = ?");
    $stmt->execute([$nome, $nascimento, $especie_id, $prontuario, $genero, $id]);
    header('Location: pets.php');
    exit;
}

// Fetch all pets with especie name
$stmt = $pdo->query("SELECT p.*, e.especie FROM pets p JOIN especies e ON p.especie_id = e.id");
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Gerenciamento de Pets</h2>

<!-- Create Form -->
<h3>Adicionar Pet</h3>
<form method="post">
    <div class="mb-3">
        <label for="nome" class="form-label">Nome do Pet</label>
        <input type="text" class="form-control" id="nome" name="nome" required>
    </div>
    <div class="mb-3">
        <label for="nascimento" class="form-label">Nascimento</label>
        <input type="date" class="form-control" id="nascimento" name="nascimento" required>
    </div>
    <div class="mb-3">
        <label for="especie_id" class="form-label">Espécie</label>
        <select class="form-control" id="especie_id" name="especie_id" required>
            <option value="">Selecione</option>
            <?php foreach ($especies as $esp): ?>
            <option value="<?php echo $esp['id']; ?>"><?php echo htmlspecialchars($esp['especie']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="prontuario" class="form-label">Prontuário</label>
        <textarea class="form-control" id="prontuario" name="prontuario" rows="3"></textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">Gênero</label><br>
        <input type="radio" id="macho" name="genero" value="macho" required>
        <label for="macho">Macho</label>
        <input type="radio" id="femea" name="genero" value="femea" required>
        <label for="femea">Fêmea</label>
    </div>
    <button type="submit" name="create" class="btn btn-primary">Adicionar</button>
</form>

<!-- List -->
<h3 class="mt-4">Lista de Pets</h3>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Nascimento</th>
            <th>Espécie</th>
            <th>Prontuário</th>
            <th>Gênero</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($pets as $pet): ?>
        <tr>
            <td><?php echo $pet['id']; ?></td>
            <td><?php echo htmlspecialchars($pet['nome']); ?></td>
            <td><?php echo $pet['nascimento']; ?></td>
            <td><?php echo htmlspecialchars($pet['especie']); ?></td>
            <td><?php echo htmlspecialchars($pet['prontuario']); ?></td>
            <td><?php echo $pet['genero']; ?></td>
            <td>
                <button class="btn btn-sm btn-warning" onclick="editPet(<?php echo $pet['id']; ?>, '<?php echo htmlspecialchars($pet['nome']); ?>', '<?php echo $pet['nascimento']; ?>', <?php echo $pet['especie_id']; ?>, '<?php echo htmlspecialchars($pet['prontuario']); ?>', '<?php echo $pet['genero']; ?>')">Editar</button>
                <a href="?delete=<?php echo $pet['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Edit Form (hidden initially) -->
<div id="editForm" style="display:none;">
    <h3>Editar Pet</h3>
    <form method="post">
        <input type="hidden" id="editId" name="id">
        <div class="mb-3">
            <label for="editNome" class="form-label">Nome do Pet</label>
            <input type="text" class="form-control" id="editNome" name="nome" required>
        </div>
        <div class="mb-3">
            <label for="editNascimento" class="form-label">Nascimento</label>
            <input type="date" class="form-control" id="editNascimento" name="nascimento" required>
        </div>
        <div class="mb-3">
            <label for="editEspecie" class="form-label">Espécie</label>
            <select class="form-control" id="editEspecie" name="especie_id" required>
                <option value="">Selecione</option>
                <?php foreach ($especies as $esp): ?>
                <option value="<?php echo $esp['id']; ?>"><?php echo htmlspecialchars($esp['especie']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="editProntuario" class="form-label">Prontuário</label>
            <textarea class="form-control" id="editProntuario" name="prontuario" rows="3"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Gênero</label><br>
            <input type="radio" id="editMacho" name="genero" value="macho" required>
            <label for="editMacho">Macho</label>
            <input type="radio" id="editFemea" name="genero" value="femea" required>
            <label for="editFemea">Fêmea</label>
        </div>
        <button type="submit" name="edit" class="btn btn-primary">Salvar</button>
        <button type="button" class="btn btn-secondary" onclick="cancelEdit()">Cancelar</button>
    </form>
</div>

<script>
function editPet(id, nome, nascimento, especie_id, prontuario, genero) {
    document.getElementById('editId').value = id;
    document.getElementById('editNome').value = nome;
    document.getElementById('editNascimento').value = nascimento;
    document.getElementById('editEspecie').value = especie_id;
    document.getElementById('editProntuario').value = prontuario;
    if (genero === 'macho') {
        document.getElementById('editMacho').checked = true;
    } else {
        document.getElementById('editFemea').checked = true;
    }
    document.getElementById('editForm').style.display = 'block';
}
function cancelEdit() {
    document.getElementById('editForm').style.display = 'none';
}
</script>

<?php
include 'includes/footer.php';
?>
