<?php
require_once 'includes/db.php';

// Insert default user if not exists
$username = 'admin';
$password = password_hash('admin', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
if (!$stmt->fetch()) {
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->execute([$username, $password]);
    echo "Usuário padrão criado: admin / admin";
} else {
    echo "Usuário já existe.";
}
?>
